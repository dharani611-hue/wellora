import { ImageWithFallback } from './components/figma/ImageWithFallback';

const projects = [
  {
    id: 1,
    title: "Typography Design",
    category: "Branding",
    image: "https://images.unsplash.com/photo-1777895816174-0cdd41ea91a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
  },
  {
    id: 2,
    title: "Architectural Models",
    category: "Product Design",
    image: "https://images.unsplash.com/photo-1771189255245-225dcea3f652?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
  },
  {
    id: 3,
    title: "Modern Architecture",
    category: "Architecture",
    image: "https://images.unsplash.com/photo-1768658500206-d6886727a35c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
  },
  {
    id: 4,
    title: "Website Design",
    category: "Digital",
    image: "https://images.unsplash.com/photo-1777503809793-e9e3c5109aa3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
  },
  {
    id: 5,
    title: "Workspace Setup",
    category: "Interior",
    image: "https://images.unsplash.com/photo-1720118727697-5bc1648e9a70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
  },
  {
    id: 6,
    title: "Minimal Desk",
    category: "Interior",
    image: "https://images.unsplash.com/photo-1720118727697-e72c2d41e4c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
  }
];

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 md:py-32">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-7xl mb-6 text-gray-900">
            Crafting stories through innovative designs
          </h1>
          <p className="text-lg md:text-xl text-gray-600 max-w-2xl">
            We transform ideas into compelling visual narratives that resonate with audiences and create lasting impressions through thoughtful design and creative excellence.
          </p>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="max-w-7xl mx-auto px-6 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div
              key={project.id}
              className="group cursor-pointer"
            >
              <div className="aspect-[4/5] overflow-hidden bg-gray-100 mb-4 rounded-lg">
                <ImageWithFallback
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="space-y-1">
                <p className="text-sm text-gray-500">{project.category}</p>
                <h3 className="text-xl text-gray-900">{project.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}